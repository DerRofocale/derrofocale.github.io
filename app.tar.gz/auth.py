import flet as ft

# Тестовые данные для авторизации
TEST_USERNAME = "login"
TEST_PASSWORD = "password"

# Список пользователей (для демонстрации на второй странице)
users = [
    {"id": 1, "name": "John Doe", "age": 30},
    {"id": 2, "name": "Jane Smith", "age": 25},
    {"id": 3, "name": "Bob Johnson", "age": 35},
]

# Состояние авторизации (пользователь авторизован или нет)
authenticated = False

def main(page: ft.Page):
    page.title = "Simple Auth App"

    # Страница авторизации
    def login_page():
        page.clean()
        page.add(ft.Text("Login Page", size=24))
        username_input = ft.TextField(label="Username")
        password_input = ft.TextField(label="Password")
        login_button = ft.ElevatedButton("Login", on_click=lambda _: login(username_input.value, password_input.value))
        page.add(username_input, password_input, login_button)

    # Страница со списком пользователей
    def user_list_page():
        page.clean()
        page.add(ft.Text("User List", size=24))
        logout_button = ft.ElevatedButton("Logout", on_click=logout)
        page.add(logout_button)

        if authenticated:
            for user in users:
                user_info = f"ID: {user['id']}, Name: {user['name']}, Age: {user['age']}"
                page.add(ft.Text(user_info))

    # Обработчик авторизации
    def login(username, password):
        global authenticated
        if username == TEST_USERNAME and password == TEST_PASSWORD:
            authenticated = True
            user_list_page()

    # Обработчик выхода из авторизации
    def logout(e):
        global authenticated
        authenticated = False
        login_page()

    # Запуск приложения на странице авторизации
    login_page()

ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=8550)
